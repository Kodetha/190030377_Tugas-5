import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart'

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {

  @override
  _MyAppState CreateState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
final  GlobalKey<ScaffoldState> _scafoldkey = new GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      Home:Scaffold(
        AppBar:AppBar( title: 'Notification Project',)
      body: Center(
        child: Column(
      MainAxisAlignment:MainAxisAlignment.center,
        children:<Widget>[
          MaterialButton(onPressed: showtoast(),Child:Text("show Toast"), )
          MaterialButton(onPressed: showSnackbar(),Child:Text("show Snackbar"), )
          ],
         ),
        ),
       ),
      ),
     );
  }

  showtoast(){
    SetState((){
      fluttertoast.showtoast(
        msg:'This Is Notification From Toast',
        toastLength: TOAST.LENGTH_long,
        gravity: ToastGravity.BOTTOM
      );
    });
  };

  void showSnackbar(){
    Setstate((){
      final SnackBar = SnackBar(
        content: Text("This Is Notification From Snackbar") )
        Duration : Duration (second :5),
        Action : SnackBarAction(
          label : undo ,onPressed : ,  }));
          _scafoldkey.currentstate.showSnackbar(SnackBar);
    });
  }
}